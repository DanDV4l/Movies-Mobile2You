import 'package:flutter/material.dart';

// Import the firebase_core plugin
import 'package:firebase_core/firebase_core.dart';
import 'package:movies/appwidget.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  runApp(const AppWidget());
}

class App extends StatefulWidget {
  const App({Key? key}) : super(key: key);

  @override
  _AppState createState() => _AppState();
}

class _AppState extends State<App> {
  @override
  Widget build(BuildContext context) {
    final Future<FirebaseApp> _initialization = Firebase.initializeApp();

    return FutureBuilder(
      future: _initialization,
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return Container(color: Colors.black);
        }

        if (snapshot.connectionState == ConnectionState.done) {
          return const AppWidget();
        }

        return Container(
          color: Colors.black,
        );
      },
    );
  }
}
