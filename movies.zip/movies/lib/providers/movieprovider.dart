import 'package:flutter/cupertino.dart';
import 'package:movies/models/movie.dart';

class MovieProvider extends ChangeNotifier {
  Movie? movie;
  int? id;

  List? _similarMovies;
  List favorites = [];

  dynamic genres;

  get similarMovies => _similarMovies;
  set similarMovies(var value) {
    _similarMovies = value;
  }

  void notify() {
    notifyListeners();
  }
}
