import 'package:flutter/cupertino.dart';

class UserProvider extends ChangeNotifier {
  var _user;

  get user => _user;
  set user(var value) {
    _user = value;

    notifyListeners();
  }
}
