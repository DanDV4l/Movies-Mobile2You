import 'package:flutter/cupertino.dart';
import 'package:movies/models/user.dart';

class UserProvider extends ChangeNotifier {
  var _user;

  get user => _user;
  set user(var value) {
    _user = value;

    notifyListeners();
  }
}
