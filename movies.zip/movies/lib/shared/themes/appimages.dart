class AppImages {
  static final google = "assets/images/google.png";
  static final loginBG = "assets/images/loginBackground.jpg";
  static final m2yLogo = "assets/images/m2ylogo.png";
}
