import 'package:flutter/material.dart';
import 'package:movies/models/user.dart';
import 'package:movies/providers/movieprovider.dart';
import 'package:movies/providers/userprovider.dart';
import 'package:movies/shared/controllers/firestorecontroller.dart';
import 'package:provider/provider.dart';

class AuthController {
  User? _userData;
  User get userData => _userData!;

  set userData(User value) {
    _userData = value;
  }

  void getFavorites(context, {required userEmail}) async {
    var _favoriteData = await getUserData(context, userEmail: userEmail);
    var _usrData = _favoriteData;
    Provider.of<UserProvider>(context, listen: false).user = userData;

    Provider.of<MovieProvider>(context, listen: false).favorites = _usrData;
    Provider.of<MovieProvider>(context, listen: false).notify();

    _userData != Null
        ? Navigator.pushReplacementNamed(context, "/home")
        : Navigator.pushReplacementNamed(context, "/login");
  }

  void login(context) {
    _userData != Null
        ? Navigator.pushReplacementNamed(context, "/home")
        : Navigator.pushReplacementNamed(context, "/login");
  }
}
