import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:movies/providers/movieprovider.dart';
import 'package:provider/provider.dart';

FirebaseFirestore firestore = FirebaseFirestore.instance;

Future<List<int>> getUserData(context, {required userEmail}) async {
  List<int> data = [];
  final _data = await firestore.collection('users').doc(userEmail).get();
  try {
    for (var i in _data['favorites']) {
      data.add(i);
    }
  } catch (err) {}
  return data;
}

Future<void> setFavorite(context, userEmail) async {
  firestore.collection('users').doc(userEmail).set({
    "favorites": Provider.of<MovieProvider>(context, listen: false).favorites
  });
}
