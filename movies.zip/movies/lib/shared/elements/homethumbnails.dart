import 'package:flutter/material.dart';
import 'package:movies/models/movie.dart';
import 'package:movies/providers/movieprovider.dart';
import 'package:movies/shared/getmovie.dart';
import 'package:provider/provider.dart';

Widget homeThumbnailMovie(context, {id}) {
  return Padding(
    padding: const EdgeInsets.all(5.0),
    child: SizedBox(
        child: FutureBuilder<Movie>(
      future: getMovieData(id: id),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const SizedBox();
        }
        if (snapshot.connectionState == ConnectionState.done) {
          var _movieData = snapshot.data;
          return buildHomeThumbnail(context,
              image: _movieData!.posterPath, id: id);
        }
        return Container(
          color: Colors.amber,
        );
      },
    )),
  );
}

Widget buildHomeThumbnail(context, {image, id}) {
  return InkWell(
    child: ClipRRect(
      borderRadius: BorderRadius.all(Radius.circular(5)),
      child: Image.network(
        image,
        fit: BoxFit.fill,
        width: 125,
        height: 160,
      ),
    ),
    onTap: () {
      Provider.of<MovieProvider>(context, listen: false).id = id;
      Navigator.pushNamed(context, '/load');
    },
  );
}
