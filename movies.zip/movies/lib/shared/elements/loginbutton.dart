import 'package:flutter/material.dart';
import 'package:movies/shared/themes/appimages.dart';
import 'package:movies/shared/themes/textstyles.dart';

Widget buildLoginButton({onTap}) {
  return InkWell(
    onTap: onTap,
    child: Container(
      height: 56,
      width: 320,
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.8),
        borderRadius: BorderRadius.only(
            bottomLeft: Radius.circular(12), bottomRight: Radius.circular(12)),
      ),
      child: Row(
        children: [
          Container(
            height: 56,
            decoration: BoxDecoration(
              border: Border(right: BorderSide(color: Colors.grey.shade700)),
            ),
            child: Padding(
              padding: const EdgeInsets.only(left: 2, right: 2),
              child: Image.asset(AppImages.google),
            ),
          ),
          Expanded(
            flex: 4,
            child: Align(
              alignment: Alignment.center,
              child: Text(
                'Entrar com o Google',
                style: Styles.listTitle,
              ),
            ),
          ),
        ],
      ),
    ),
  );
}
