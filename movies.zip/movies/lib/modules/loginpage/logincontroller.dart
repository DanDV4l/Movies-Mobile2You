import 'package:flutter/material.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:movies/models/user.dart';
import 'package:movies/modules/loginpage/authcontroller.dart';

class LoginController {
  Future<void> googleSignIn(BuildContext context) async {
    GoogleSignIn _googleSignIn = GoogleSignIn(
      scopes: [
        'email',
      ],
    );
    try {
      final response = await _googleSignIn.signIn();
      AuthController _authController = AuthController();
      _authController.userData = User(
        name: response!.displayName!,
        photoURL: response.photoUrl,
        email: response.email,
      );
      _authController.login(context);
    } catch (err) {
      print(err);
    }
  }
}
