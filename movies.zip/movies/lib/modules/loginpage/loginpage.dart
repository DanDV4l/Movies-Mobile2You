import 'package:flutter/material.dart';
import 'package:movies/shared/elements/loginbutton.dart';
import 'package:movies/shared/controllers/logincontroller.dart';
import 'package:movies/shared/themes/appcolors.dart';
import 'package:movies/shared/themes/appimages.dart';
import 'package:movies/shared/themes/textstyles.dart';

class LoginPage extends StatelessWidget {
  const LoginPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    LoginController _loginController = LoginController();
    var _getScreenSize = MediaQuery.of(context).size;

    return Stack(
      children: [
        Image.asset(
          AppImages.loginBG,
          width: _getScreenSize.width,
          height: _getScreenSize.height,
          fit: BoxFit.fill,
        ),
        Scaffold(
            backgroundColor: Colors.transparent,
            appBar: AppBar(
              title: Text("Movies"),
              backgroundColor: AppColors.background,
            ),
            body: SingleChildScrollView(
              child: Expanded(
                child: SizedBox(
                  width: MediaQuery.of(context).size.width,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Image.asset(AppImages.m2yLogo),
                      const SizedBox(
                        height: 125,
                      ),
                      Container(
                        padding: EdgeInsets.all(10),
                        width: 320,
                        decoration: BoxDecoration(
                          color: Colors.grey.shade900.withOpacity(0.9),
                          borderRadius: BorderRadius.only(
                              topLeft: Radius.circular(12),
                              topRight: Radius.circular(12)),
                        ),
                        child: Text(
                          "Seja bem vindo(a) ao app Movies! Utilize sua conta Google para entrar, conhecer filmes e guardar seus favoritos.",
                          style: Styles.loginText,
                          textAlign: TextAlign.center,
                        ),
                      ),
                      buildLoginButton(onTap: () {
                        _loginController.googleSignIn(context);
                      }),
                      const SizedBox(
                        height: 125,
                      ),
                      Text(
                        "DESENVOLVIDO POR: DANIEL SOUZA PINTO\nDesafio técnico proposto pela equipe Mobile2You.",
                        style: Styles.buttons,
                        textAlign: TextAlign.center,
                      )
                    ],
                  ),
                ),
              ),
            ))
      ],
    );
  }
}
