import 'package:flutter/material.dart';
import 'package:movies/modules/loginpage/elements/loginbutton.dart';
import 'package:movies/modules/loginpage/logincontroller.dart';
import 'package:movies/shared/themes/appcolors.dart';

class LoginPage extends StatelessWidget {
  const LoginPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    LoginController _loginController = LoginController();

    return Scaffold(
        backgroundColor: AppColors.background,
        appBar: AppBar(
          backgroundColor: AppColors.primary,
        ),
        body: SingleChildScrollView(
          child: SizedBox(
            width: MediaQuery.of(context).size.width,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                SizedBox(
                  height: 200,
                ),
                buildLoginButton(onTap: () {
                  _loginController.googleSignIn(context);
                })
              ],
            ),
          ),
        ));
  }
}
