import 'package:flutter/material.dart';
import 'package:movies/shared/themes/appcolors.dart';

Widget buildLoginButton({required onTap}) {
  return InkWell(
    onTap: onTap,
    child: Container(
      width: 240,
      height: 60,
      decoration: BoxDecoration(
          color: AppColors.buttons,
          border: Border.all(color: AppColors.primary),
          borderRadius: BorderRadius.all(Radius.circular(15))),
    ),
  );
}
