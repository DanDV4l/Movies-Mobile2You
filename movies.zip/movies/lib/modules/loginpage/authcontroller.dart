import 'package:flutter/material.dart';
import 'package:movies/models/user.dart';

class AuthController {
  User? _userData;
  User get userData => _userData!;

  set userData(User value) {
    _userData = value;
  }

  void login(context) {
    print(_userData!.email);
    _userData != Null
        ? Navigator.pushNamed(context, "/home")
        : Navigator.pushNamed(context, "/login");
  }
}
