class User {
  final String name;
  final String email;
  final String? photoURL;

  User({required this.name, required this.email, this.photoURL});
}
