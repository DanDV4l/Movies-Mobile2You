import 'package:flutter/material.dart';
import 'package:movies/modules/detailspage/detailspage.dart';
import 'package:movies/modules/homepage/homepage.dart';
import 'package:movies/modules/loadingpage/loadingpage.dart';
import 'package:movies/modules/loginpage/loginpage.dart';
import 'package:movies/providers/movieprovider.dart';
import 'package:movies/providers/similarprovider.dart';
import 'package:movies/shared/elements/errorpage.dart';
import 'package:provider/provider.dart';

class AppWidget extends StatefulWidget {
  const AppWidget({Key? key}) : super(key: key);

  @override
  State<AppWidget> createState() => _AppWidgetState();
}

class _AppWidgetState extends State<AppWidget> {
  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => MovieProvider()),
        ChangeNotifierProvider(
          create: (_) => SimilarMovieProvider(),
        )
      ],
      child: MaterialApp(
        title: 'MOVIES - Mobile2You',
        routes: {
          "/home": (context) => const HomePage(),
          "/splash": (context) => LoginPage(),
          "/login": (context) => const LoginPage(),
          "/load": (context) => const LoadingPage(),
          "/details": (context) => const DetailsPage(),
          "/error": (context) => const ErrorPage()
        },
        initialRoute: "/login",
      ),
    );
  }
}
