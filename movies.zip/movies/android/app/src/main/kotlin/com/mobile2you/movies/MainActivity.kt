package com.mobile2you.movies

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
